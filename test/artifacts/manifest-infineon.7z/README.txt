Dear User,

The bundle file you retrieved contains the data belonging to the devices on 
the reel specified in the file name. 
The bundle file is "an archive of archives" structured as follows:

Bundle file 
----- reelID_GUID_vx.y.7z ------
|                              |
|   reelID_GUID_E0E0_Certs.7z  |     
|                              |
|   reelID_GUID_E0E1_Certs.7z  |
|                              |
|   reelID_GUID_E0E2_Certs.7z  |
|                              |
|   reelID_GUID_keys.7z        |
|                              |
|   README.txt                 |
|                              |
--------------------------------

reelID_GUID_E0E0_Certs.7z 
This archive contains the certificates stored in data object E0E0, as device 
individual .pem files. 
The individual file names follow the convention: chipID_E0E0.pem to allow 
matching certificate - device.

reelID_GUID_E0E1_Certs.7z
This archive contains the certificates stored in data object E0E1, as device 
individual .pem files. 
The individual file names follow the convention: chipID_E0E1.pem to allow 
matching certificate - device.
Please note that the certificate from E0E1 data object is usable only under 
shielded connection!

reelID_GUID_E0E2_Certs.7z
This archive contains the certificates stored in data object E0E2, as device 
individual .pem files. 
The individual file names follow the convention: chipID_E0E2.pem to allow 
matching certificate - device.

reelID_GUID_keys.7z
This file is an encrypted archive containing chip individual PBS and 
authorization keys. The decryption key is available in the reel associated 
letter and is named "transport key". 
PBS and authorization keys are included as text files in this archive. 
The files have 1 record/line, structured as: 

   chipID, PBS key 
or
   chipID, authorization key 
   
The records are represented as hexadecimal strings, i.e. 2 charcters/byte. 



CA Certificates
===============
The certificates of the CAs needed for end device certificate validation are
available as follows:

The root CA certificates:
http://pki.infineon.com/OptigaEccRootCA2/OptigaEccRootCA2.crt
http://pki.infineon.com/OptigaRsaRootCA2/OptigaRsaRootCA2.crt

The intermediate CA certificates: 
https://pki.infineon.com/OptigaTrustEccCA306/OptigaTrustEccCA306.crt 
https://pki.infineon.com/OptigaTrustRsaCA309/OptigaTrustRsaCA309.crt 



Remarks
=======
The bundle file might contain more certificates than devices on the reel. 
This is due to the way the devices are assembled, tested and packed on the reel. 
However the extra certificates can be safely ignored as the matching devices 
were scrapped during the testing and packaging steps. 



Final note
==========
Should any difficulties occur, our support will be happy to help. Simply send an email,
indicating the order details and affected reel IDs, by visiting https://www.infineon.com/tac.
Remember to handle Batch ID(GUID) and QR code confidentially!

